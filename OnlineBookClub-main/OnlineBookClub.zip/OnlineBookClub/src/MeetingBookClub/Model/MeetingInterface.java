package MeetingBookClub.Model;

public interface MeetingInterface {
    String getMeeting();
}
