package MeetingBookClub.View;

import javax.swing.*;

public class MeetingListView {
    private JLabel MeetingListTitle;
    private JList ListofMeetings;
    private JButton AddToList;
}
