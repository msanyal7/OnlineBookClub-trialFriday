package Homepage.View;

public class HomepageView {

    public void show() {
        System.out.println("Rendering Homepage View...");
    }
}
