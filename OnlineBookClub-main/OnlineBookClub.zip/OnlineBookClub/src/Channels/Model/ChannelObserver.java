package Channels.Model;

public interface ChannelObserver {
    void onCommentAdded(Comment comment);
}
